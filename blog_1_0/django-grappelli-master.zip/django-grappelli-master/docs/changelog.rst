:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _changelog:

Changelog
=========

2.9.2 (not yet released)
------------------------

2.9.1 (November 8th 2016)
-------------------------

* First release of Grappelli which is compatible with Django 1.10.
