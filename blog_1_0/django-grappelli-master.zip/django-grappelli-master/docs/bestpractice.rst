:tocdepth: 2

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _faq:

Best Practice
=============

Some tips in order to make the most of Grappelli.

M2M horizontal/vertical
-----------------------

Most of the time, it's probably better to use Autocompletes.

Radiolists/Checkboxlists
------------------------

If you're having more than (say) 5 items to choose from, avoid using this (esp. with tabular/stacked Inlines).