.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

Internals
=========

.. toctree::
   :maxdepth: 1
   
   templates
   javascripts