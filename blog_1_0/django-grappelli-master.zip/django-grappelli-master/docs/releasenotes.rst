:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 2.9.x Release Notes
=============================

**Grappelli 2.9.x is compatible with Django 1.10**.

Update from Grappelli 2.8.x
---------------------------

* Update Django to 1.10 and check https://docs.djangoproject.com/en/dev/releases/1.10/
* Update Grappelli to 2.9.x
